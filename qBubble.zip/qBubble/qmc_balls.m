function [xyzw,X,bbox,domain_volume] = qmc_balls(centers,radii,N,pointset_type,do_plot)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% This routine determines the volume of the union of spheres via QMC, providing a QMC set "X"  
% of "N" points on the bounding box of the domain, and determining the set of points "xyz" in 
% the union of spheres with their weights "w".
% Furthermore it computes via QMC the volume "V" of the union of balls.
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% centers: N x 3 matrix describing the centers in cartesian coordinates;
% radii: N x 1 vector, in which radii(k) is the radius of the k-th ball;
% N: number of points in the bounding box
% pointset_type: string determining the 3D low discrepancy pointset to be used:
%             'S': sobolset, 'H': haltonset, 'R': random 
% do_plot: plots QMC pointset;
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% xyzw: N x 4 matrix, in which xyzw(:,1:3) are the nodes described in cartesian
%           coordinates and xyzw(:,4) are the weights of the QMC rule.
% X: N x 3 pointset in the bounding box;
% bbox: bounding box as [xmin xmax; ymin ymax; zmin zmax]';
% domain_volume: approximate domain volume.
%--------------------------------------------------------------------------
% AUTHORS
%---------------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%---------------------------------------------------------------------------------
% PAPER
%---------------------------------------------------------------------------------
% "Qbubble: a numerical code for compressed QMC volume and surface integration on union of 
% spheres"
% G. Elefante, A. Sommariva and M. Vianello
%---------------------------------------------------------------------------------
%  RELEASE DATE
%---------------------------------------------------------------------------------
% First version: November 2022
% Last update: February 6, 2023
%---------------------------------------------------------------------------------


% troubleshooting
if nargin < 4, N = 2*10^6; end % Points on the bounding box 
if nargin < 4, pointset_type = 'H'; end % Type of points
if nargin < 5, do_plot = 0; end % Do Plot 

% Minimal box containing the spheres
a = min(centers-radii',[],1); b = max(centers+radii',[],1);

% Pointset in the bounding box.
switch pointset_type
    case 'S'
        p = sobolset(3); X = net(p,N); clear p;
    case 'H'
        p = haltonset(3); X = net(p,N); clear p;
    case 'R'
        X = rand(N,3);
    otherwise
        p = haltonset(3); X = net(p,N); clear p;
end

% Mapping the points in the minimal box
X = [(b(1)-a(1)).*X(:,1)+a(1), (b(2)-a(2)).*X(:,2)+a(2), ...
    (b(3)-a(3)).*X(:,3)+a(3)];

% Searching for the nodes inside the bubble
P = zeros(N,1);
for i = 1:length(radii)
    P = P + ( (X(:,1)-centers(i,1)).^2 + (X(:,2)-centers(i,2)).^2 + ...
        (X(:,3)-centers(i,3)).^2 - radii(i).^2 <= 0 );
end

% Determine cubature rule
idx = P>0;
xyz=X(idx,:); w=prod(b-a)/N;
xyzw=[xyz w*ones(size(xyz,1),1)];

% Bounding box
bbox=[a(1) b(1); a(2) b(2); a(3) b(3)]';

% Compute approximate domain volume
domain_volume = sum(xyzw(:,4));

% Plot QMC pointset
if do_plot 
    [XX,YY,ZZ] = sphere;
    for i = 1:length(radii)
        surf(radii(i)*XX + centers(i,1),radii(i)*YY + centers(i,2),radii(i)*ZZ + centers(i,3),'EdgeColor','none','FaceLighting','gouraud','FaceColor',[220 220 220]/256,'FaceAlpha',0.05)
        axis equal
        hold on;
    end
    plot3(xyz(:,1),xyz(:,2),xyz(:,3),'.',"MarkerEdgeColor",[149 149 149]/256,'MarkerSize',4)
end


