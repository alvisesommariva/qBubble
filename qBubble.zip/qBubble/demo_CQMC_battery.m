
function demo_CQMC_battery

%---------------------------------------------------------------------------------
% OBJECT:
%---------------------------------------------------------------------------------
% Numerical cubature over volumes/surfaces defined by union of balls/spheres.
% The routine tests the quality of quadrature rules with degree of precision "deg" over 
% polynomials of the form:
%                                 f=@(x,y,z) (a1+b1*x+c1*y+d1*z).^deg;
% where "a1", "b1", "c1", "d1" are random numbers.
% FInally it plots, if requires, the relative errors of each test, for some "deg" and logarithmic 
% averages.
%---------------------------------------------------------------------------------
% AUTHORS
%---------------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%---------------------------------------------------------------------------------
% PAPER
%---------------------------------------------------------------------------------
% "Qbubble: a numerical code for compressed QMC volume and surface integration on union of 
% spheres"
% G. Elefante, A. Sommariva and M. Vianello
%---------------------------------------------------------------------------------
%  RELEASE DATE
%---------------------------------------------------------------------------------
% First version: November 2022
% Last update: February 6, 2023
%---------------------------------------------------------------------------------

% 1. volume, 2. surface.
domain = 2; 

% Test domain, 1: 3 balls/spheres, 2: 100 balls/spheres
example =1; 

% Compressed QMC degree of precision to be analysed.
degV = 3:3:12; 

% Cardinality of the pointset on each sphere (surface), domain bounding box (volume).
% Having in mind to reproduce the numerical tests choose, e.g., the following values:
% Volume: card=2400000 (points in the bounding box)
% Surface: example 1, card=500000,  (points on each sphere)
%              example 2, card=60000,  (points on each sphere)
card = 60000; 

% Plot domains/pointsets: 0: no plot 1: plot.
do_plot = 1; 

% Cubature comparison on a number "tests" integrals.
tests=100; 

% Low discrepancy set.
% pointset_type: string determining the 3D low discrepancy pointset to be used:
%             'S': sobolset, 'H': haltonset, 'R': random 
pointset_type='H';


% ..... Some technical parameters for compression ......

tol=1e-10; % Compression tolerance.
comp_type=2; % 1: lsqnonneg 2: LHDM. 




% ..................................................... Main code below ..................................................................

[centers,radii,xP,x0]=define_domain(example,domain); % define domain


res1={}; cpu_comp1=[]; card1=[]; TW1={}; XYZW1={}; LHDM_stats1={};

% Defining QMC rule

fprintf('\n \n \t ...................... QMC RULE .....................')

switch domain
    case 1
        tic
        [xyzw,X,bbox,volume] = qmc_balls(centers,radii,card,pointset_type,0);
        cpu_time1 = toc;
        XYZ=xyzw(:,1:3); W=xyzw(:,4); 
    case 2
        tic
        [xyzw,X,bbox,area] = qmc_spheres(centers,radii,card,pointset_type,0);
        cpu_time1 = toc;
        XYZ=xyzw(:,1:3); W=xyzw(:,4); 
end
fprintf('\n \t cpu time: %1.2e',cpu_time1);


% Perform compression, varying the algebraic degree of exactness

fprintf('\n \t ...................... COMPRESSION .....................')

REV1=[]; logerrV1=[]; REV2=[]; logerrV2=[];
for deg=degV

    fprintf('\n \t * Performing compression, deg: %2d',deg);

    fprintf('\n \t ** dCATCH');
    [T1,w1,res1,dbox1] = dCATCH(deg,XYZ,W);

    fprintf('\n \t ** cqmc_v2');
    [T2,w2,res2,moms2,LHDM_stats2] = cqmc_v2(deg,XYZ,tol,comp_type,W,domain);

    fprintf('\n \t ** testing quality over %4.0f tests',tests);
    for k=1:tests
         % Define integrand
         a1=rand(1); b1=rand(1); c1=rand(1); d1=rand(1);
         f=@(x,y,z) (a1+b1*x+c1*y+d1*z).^deg;
                
         % Full QMC.
         xx=XYZ(:,1); yy=XYZ(:,2); zz=XYZ(:,3);
         fXY=feval(f,xx,yy,zz);
         I0=W'*fXY;
                
         % dCATCH
         xxdc=T1(:,1); yydc=T1(:,2); zzdc=T1(:,3);
         fc=feval(f,xxdc,yydc,zzdc);
         I1=w1'*fc;

         % CQMC_v2
         xxc=T2(:,1); yyc=T2(:,2); zzc=T2(:,3);
         fc=feval(f,xxc,yyc,zzc);
         I2=w2'*fc;
                
         RE1(k,1)=abs((I0-I1)./I1); % Relative error dCATCH
         RE2(k,1)=abs((I0-I2)./I2); % Relative error CQMC_v2
         
     end

      % ..... Statistics  .....
            
     fprintf('\n \t ... dCATCH ...');
     fprintf('\n \t DEG   : %2.0f',deg);
     fprintf('\n \t RE max: %1.3e',max(RE1));
     kpos=find(RE1 > 0);
     logerr1=10^(sum(log10(RE1(kpos)))/length(kpos));
     fprintf('\n \t RE log: %2.3e',logerr1);

     fprintf('\n \t ... CQMC_v2 ...');
     fprintf('\n \t DEG   : %2.0f',deg);
     fprintf('\n \t RE max: %1.3e',max(RE2));
     kpos2=find(RE2 > 0);
     logerr2=10^(sum(log10(RE2(kpos2)))/length(kpos2));
     fprintf('\n \t RE log: %2.3e \n',logerr2);
          
     REV1=[REV1 RE1];
     logerrV1=[logerrV1; logerr1];

     REV2=[REV2 RE2];
     logerrV2=[logerrV2; logerr2];
end


% plotting results about the quality of numerical quadrature (testing degree of precision)

if do_plot
    h1=figure(1);
    f1=ishandle(h1)&&strcmp(get(h1,'type'),'figure'); if f1,clf(1);end
    figure(1)
    axis equal;
    if sum(isnan(REV1)) == length(REV1)
        fprintf(2,'\n \t * Figure 3: No error to plot. \n ')
    else
        for jj=1:length(degV)
            n=degV(jj);
            reL=REV1(:,jj); log_reL=logerrV1(jj);
            plot_errors(jj,n,reL,log_reL);
            hold on;
        end
        ax=gca;
        ax.XAxis.FontSize = 8;
        ax.YAxis.FontSize = 8;
        xlim([degV(1)-1,degV(end)+1]);
        xticks(degV)
        title('Polynomial integrals matching between QMC and dCATCH','FontSize',9)
        hold off
    end

    h2=figure(2);
    f2=ishandle(h2)&&strcmp(get(h2,'type'),'figure'); if f2,clf(2);end
    figure(2)
    axis equal;
    if sum(isnan(REV2)) == length(REV2)
        fprintf(2,'\n \t * Figure 4: No error to plot. \n ')
    else
        for jj=1:length(degV)
            n=degV(jj);
            reL=REV2(:,jj); log_reL=logerrV2(jj);
            plot_errors(jj,n,reL,log_reL);
            hold on;
        end
        ax=gca;
        ax.XAxis.FontSize = 8;
        ax.YAxis.FontSize = 8;
        xlim([degV(1)-1,degV(end)+1]);
        xticks(degV)
        title('Polynomial integrals matching between QMC and CQMC\_v2','FontSize',9)
        hold off;
    end
end


% plot_errors
function plot_errors(ii,n,reV,log_re)

if ii <= 27
    
    randV=[
        0.6962    0.0294    0.6081
        0.8814    0.7115    0.7701
        0.0247    0.5384    0.9411
        0.3412    0.5246    0.1315
        0.4214    0.5022    0.2557
        0.0800    0.0657    0.3783
        0.0794    0.2300    0.9937
        0.0724    0.1170    0.3410
        0.9003    0.9898    0.8996
        0.9693    0.0705    0.2375
        0.3913    0.0600    0.2200
        0.3136    0.6616    0.9911
        0.5533    0.3441    0.9511
        0.7920    0.1285    0.6382
        0.7983    0.6371    0.5041
        0.8633    0.7465    0.3581
        0.7980    0.8053    0.7685
        0.0064    0.2690    0.7844
        0.9199    0.4340    0.0289
        0.0180    0.4018    0.0524];
    
    switch ii
        case 1
            colorstr='m'; linestr='m-';
        case 2
            colorstr='g'; linestr='g-';
        case 3
            colorstr='r'; linestr='r-';
        case 4
            colorstr='b'; linestr='b-';
        case 5
            colorstr='c'; linestr='b-';
        case 6
            colorstr='y'; linestr='b-';
        case 7
            colorstr='k'; linestr='b-';
        otherwise
            colorstr=randV(ii-7,:); linestr='b-';
    end
    
    semilogy(n*ones(size(reV)),reV,'+','color',colorstr,'LineWidth',2);
    hold on;
    semilogy(n,log_re, 'ko','MarkerSize',12,'MarkerEdgeColor','k',...
        'LineWidth',2);
else
    semilogy(n*ones(size(reV)),reV,'color',rand(1,3)); hold on;
    semilogy(n,log_re, 'ko','MarkerSize',12,'MarkerEdgeColor','k');
end





function [centers,radii,xP,x0]=define_domain(example,domain)

%---------------------------------------------------------------------------------
% INPUTS:
% example: 1: 3 balls/spheres, 2: 100 balls/spheres.
% domain: 1. volume, 2. surface.
%---------------------------------------------------------------------------------
% OUTPUTS:
% centers,radii,xP,x0: parameters defining the domain
%---------------------------------------------------------------------------------

switch example
    
     case 1 % 3 spheres
        centers = [0 0 0;  0 1.3 -0.2;  2.5 0 1];
        radii = [1.4, 0.9, 2.6];
        xP = [-1.4,0,0];
        x0 = [0,0,0] + (domain==2)*xP;

    case 2  % 100 spheres
        rng(1000);
        N=100;
        centers=2*rand(N,3);
        radii=0.2+0.4*rand(1,N);
        xP = [centers(2,1)-radii(1),centers(2,2),centers(2,3)];
        x0 = [0,0,0] + (domain==2)*xP;
end

Nballs=length(radii);

switch domain 
    case 1
        fprintf('\n \t The domain is a surface, defined by %4.0f balls', Nballs);
    case 2
        fprintf('\n \t The domain is a volume, defined by %4.0f spheres', Nballs);
end


