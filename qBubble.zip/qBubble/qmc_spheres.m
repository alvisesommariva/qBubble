function [xyzw,X,bbox,A] = qmc_spheres (centers,radii,N,pointset_type,do_plot)

%---------------------------------------------------------------------------------
% OBJECT
%---------------------------------------------------------------------------------
% This routine determines a QMC cubature rule on the (outer) surface of the union of spheres  
% defined by there "centers" and "radii".
% In particular it provides a QMC cubature rule, stored in "xyzw", where
% 1. the nodes correspond to xyzw(:,1:3)
% 2. the weights correspond to xyzw(:,1:4)
% Furthermore, the value "A(k)" is the area of the subregion of the k-th sphere, that belongs to 
% such  (outer) surface
%---------------------------------------------------------------------------------
% INPUT
%---------------------------------------------------------------------------------
% centers: N x 3 matrix describing the centers in cartesian coordinates;
% radii: N x 1 vector, in which radii(k) is the radius of the k-th ball;
% N: number of points in each sphere
% pointset_type: string determining the 3D low discrepancy pointset to be used:
%             'S': sobolset, 'H': haltonset, 'R': random 
% do_plot: plots QMC pointset;
%---------------------------------------------------------------------------------
% OUTPUT
%---------------------------------------------------------------------------------
% xyzw: N x 4 matrix, in which xyzw(:,1:3) are the nodes described in cartesian
%           coordinates and xyzw(:,4) are the weights of the QMC rule.
% X:       N x 3 pointset in the bounding box, containing the nodes;
% bbox: bounding box as [xmin xmax; ymin ymax; zmin zmax]';
% domain_volume: approximate domain volume.
%---------------------------------------------------------------------------------
% AUTHORS
%---------------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%---------------------------------------------------------------------------------
% PAPER
%---------------------------------------------------------------------------------
% "Qbubble: a numerical code for compressed QMC volume and surface integration on union of 
% spheres"
% G. Elefante, A. Sommariva and M. Vianello
%---------------------------------------------------------------------------------
%  RELEASE DATE
%---------------------------------------------------------------------------------
% First version: November 2022
% Last update: February 6, 2023
%---------------------------------------------------------------------------------




% Troubleshooting
if nargin < 3, Nsph=length(radii); N = ceil(2*10^6/Nsph); end % Points on each sphere 
if nargin < 4, pointset_type = 'H'; end % Plot of spheres
if nargin < 5, do_plot = 0; end % plot pointset

% Minimal box containing the spheres
a = min(centers-radii',[],1); b = max(centers+radii',[],1);

% Choosing QMC points.
switch pointset_type
    case 'S'
        p = sobolset(2); X = net(p,N); clear p;
    case 'H'
        p = haltonset(2); X = net(p,N); clear p;
    case 'R'
        X = rand(N,2);
end

% Defining points on the sphere.

% a) mapping points into the rectangle [-1,1]x[0,2pi]
X = [2*X(:,1)-1, X(:,2)*2*pi];

% b) mapping the points on the unitary sphere
S = [sqrt(1-X(:,1).^2).*cos(X(:,2)),     sqrt(1-X(:,1).^2).*sin(X(:,2)),     X(:,1)];

Nsph = size(centers,1); % Number of centers
PtsBound = zeros(N*Nsph,3);

% Ordering Points in the all the spheres to obtain a sequence in the union
for i = 1:Nsph
    PtsBound(i:Nsph:end) = radii(i)*S + centers(i,:);
end

% Testing if the points are on the boundary/outside of each sphere or inside any other.
tol = -1e-14;
Y = zeros(size(PtsBound,1),1);
for i = 1:Nsph
    Y = Y + (((PtsBound(:,1)-centers(i,1)).^2+(PtsBound(:,2)-centers(i,2)).^2+...
        (PtsBound(:,3)-centers(i,3)).^2-radii(i)^2)>tol);
end

% Selecting the points on the boundary of the union
idx = (Y==Nsph);
xyz = PtsBound(idx,:);

% Computing the area of the surface as percentage of each sphere
A = [];
N1 = [];
w = zeros(size(xyz,1),1);
for i = 1:Nsph
    xyz_sphere = ismember(xyz,radii(i)*S + centers(i,:),'rows');
    N1 = [N1, sum(xyz_sphere)];
    A = [A, sum(xyz_sphere)/N*4*pi*radii(i)^2];
    idx = find(w(xyz_sphere));
    ww = w(xyz_sphere(idx)); 
    w(xyz_sphere) = ones(N1(i),1)*A(i)/N1(i);
    w(xyz_sphere(idx)) = w(xyz_sphere(idx)) + ww;
end

% Constructing the output matrix and a box containing the union of spheres
xyzw=[xyz w];
bbox=[a(1) b(1); a(2) b(2); a(3) b(3)]';

% Plot QMC pointset
if do_plot 
     [XX,YY,ZZ] = sphere;
    for i = 1:length(radii)
        surf(radii(i)*XX + centers(i,1),radii(i)*YY + centers(i,2),radii(i)*ZZ + centers(i,3),'EdgeColor','none','FaceLighting','gouraud','FaceColor',[220 220 220]/256,'FaceAlpha',0.05)
        axis equal
        hold on;
    end
    plot3(xyz(:,1),xyz(:,2),xyz(:,3),'.',"MarkerEdgeColor",[149 149 149]/256,'MarkerSize',4)
end

