function demo_CQMC

%---------------------------------------------------------------------------------
% OBJECT.
%---------------------------------------------------------------------------------
% In this demo we compute a cubature rule on a union of balls or on its surface via QMC formulae.
%
% Once the domain is available, we compute a full rule QMC and a compressed
% one, say CQMC, sharing the same integrals for polynomials up to a total
% degree.
%---------------------------------------------------------------------------------
% DATES
%---------------------------------------------------------------------------------
% First version: May 28, 2022;
% Checked: February 14, 2023.
%---------------------------------------------------------------------------------
% AUTHORS
%---------------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%---------------------------------------------------------------------------------
% PAPER
%---------------------------------------------------------------------------------
% "Qbubble: a numerical code for compressed QMC volume and surface integration on union of
% spheres"
% G. Elefante, A. Sommariva and M. Vianello
%---------------------------------------------------------------------------------
%  RELEASE DATE
%---------------------------------------------------------------------------------
% First version: November 2022
% Lasta update: February 15, 2023
%---------------------------------------------------------------------------------


% 1. volume, 2. surface.
domain = 2;

% Test domain, 1: 3 balls/spheres, 2: 100 balls/spheres
example =2;

% Compressed QMC degree of precision to be analysed.
degV = 3;

% Cardinality of the pointset on each sphere (surface), domain bounding box (volume).
% Having in mind to reproduce the numerical tests choose, e.g., the following values:
% Volume: card=2400000 (points in the bounding box)
% Surface: example 1, card=500000,  (points on each sphere)
%               example 2, card=60000,  (points on each sphere)
card = 1000;

% Plot domains/pointsets: 0: no plot 1: plot.
do_plot = 1;

% Test functions:
% 0: exp(-((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2));
% 1: cos(x+y+z);
% 2: ((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2).^(3/2);
% 3: ((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2).^(5/2);
test_tunction = 2;

% QMC compression.
% 0: dCATCH;      1: CQMC_v0;    2: CQMC_v2
method = 0;

% Low discrepancy set.
% pointset_type: string determining the 3D low discrepancy pointset to be used:
%             'S': sobolset, 'H': haltonset, 'R': random
pointset_type='S';

% ..... Some technical parameters for compression ......

tol=1e-10; % Compression tolerance.
compression_type=2; % 1: lsqnonneg 2: LHDM.




% ......................................................... Main code below ...............................................................

% ..... Define compression of QMC rule .....

switch method
    case 0
        met = 'dCATCH';
    case 1
        met = 'CQMC_v1';
    case 2
        met = 'CQMC_v2';
end


% ..... Define domain .....

[centers,radii,xP,x0]=define_domain(example,domain); % define domain

% ..... Define integrands .....

switch test_tunction
    case 0
        f = @(x,y,z) exp(-((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2));
    case 1
        f = @(x,y,z) cos(x+y+z);
    case 2
        f = @(x,y,z) ((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2).^(3/2);
    case 3
        f = @(x,y,z) ((x-x0(1)).^2+(y-x0(2)).^2+(z-x0(3)).^2).^(5/2);
end

% ..... Reference Values .....
[f1,f2,f3,f4,TrueInt]=reference_values(domain,example,test_tunction);


% ........... Make battery of tests ...........

XYZ=[]; bbox=[];  SHP=[];
res1={}; cpu_comp1=[]; card1=[]; TW1={}; XYZW1={}; LHDM_stats1={};

fprintf('\n \n \t ........................ QMC RULE ...................... \n' )

switch domain

    case 1
        tic
        [xyzw,X,bbox,volume] = qmc_balls(centers,radii,card,pointset_type,do_plot);
        cpu_time1 = toc;
        XYZ=xyzw(:,1:3); W=xyzw(:,4);

    case 2
        tic
        [xyzw,X,bbox,area] = qmc_spheres(centers,radii,card,pointset_type,do_plot);
        cpu_time1 = toc;
        XYZ=xyzw(:,1:3); W=xyzw(:,4);
end

Iqmc=W'*feval(f,XYZ(:,1),XYZ(:,2),XYZ(:,3));
AEqmc = abs(Iqmc-TrueInt);
REqmc = abs(AEqmc/TrueInt);
fprintf('\n \t Ref value         : %1.15e',TrueInt);
fprintf('\n \t QMC value         : %1.15e',Iqmc);
fprintf('\n \n \t ae  QMC-TrueInt   : %1.2e',AEqmc);
fprintf('\n \t re  QMC-TrueInt   : %1.2e',REqmc);
fprintf('\n \n \t cpu time QMC      : %1.2e \n',cpu_time1);

fprintf('\n \t ...................... COMPRESSION .....................')
fprintf('\n \n \t * method: %s',met);
Ic=[]; ae=[]; re=[]; aeT=[]; reT=[]; SQMCcomp = []; i = 1;
for deg=degV

    fprintf('\n \n \t *  Performing compression, deg: %2.0f',deg);
    tic
    switch method
        case 0
            [T,w,res,dbox] = dCATCH(deg,XYZ,W);
        case 1
            [T,w,res,mom] = cqmc_v1(deg,XYZ,tol,W,domain);
        case 2
            [T,w,res,moms,LHDM_stats] = cqmc_v2(deg,XYZ,tol,compression_type,W,domain);
    end
    cpu_time2 = toc;
    Ic(end+1) = w'*feval(f,T(:,1),T(:,2),T(:,3));

    ae(end+1) = abs(Ic(end)-Iqmc); % absolute error w.r.t. QMC
    re(end+1) = ae(end)/abs(Iqmc); % relative error w.r.t. QMC
    aeT(end+1) = abs(Ic(end)-TrueInt); % absolute error w.r.t. reference integral
    reT(end+1) = aeT(end)/abs(TrueInt); % relative error w.r.t. reference integral

    fprintf('\n \n \t QMC value        : %1.15e',Iqmc);
    fprintf('\n \t CQMC value       : %1.15e \n',Ic(end)); % value compressed integral

    for j=1:length(res)
        fprintf('\n \t residue iter %2d  : %1.2e',j,res(j));
    end

    fprintf('\n \n \t ae  CQMC-TrueInt : %1.2e',aeT(end));
    fprintf('\n \t re  CQMC-TrueInt : %1.2e',reT(end));
    fprintf('\n \t ae  CQMC-QMC     : %1.2e',ae(end));
    fprintf('\n \t re  CQMC-QMC     : %1.2e',re(end));

    fprintf('\n \n \t cpu_time CQMC    : %1.2e \n ',cpu_time2);

    SQMCcomp(i) = size(T,1); i = i+1;

    if do_plot
        grayColor = [.7 .7 .7];
        clear_figure(1)
        figure(1);
        title('CQMC set');
        plot3(T(:,1),T(:,2),T(:,3),'.', 'MarkerSize',10,'Color',grayColor);
        axis off
        clear_figure(2)
        figure(2);
        title('QMC set');
        plot3(xyzw(:,1),xyzw(:,2),xyzw(:,3),'.', 'MarkerSize',10,'Color',grayColor);
        axis equal;
        axis off;
    end


end


% ..... Make statistics ......

fprintf('\n \n \t ...................... STATISTICS ......................')
fprintf('\n \n \t Cardinality QMC    : %7.0f',size(XYZ,1));
for i = 1:length(SQMCcomp)
    fprintf('\n  \n \t CQMC degree        :    %2d',degV(i)) ;
    fprintf('\n \t Cardinality CQMC   :  %4.0f',SQMCcomp(i));
    fprintf('\n \t Compression ratio  :   %6.1f   ',size(XYZ,1)/SQMCcomp(i));
end

fprintf('\n \n \t ........................................................')
fprintf('\n \n ');







function [centers,radii,xP,x0]=define_domain(example,domain)

%---------------------------------------------------------------------------------
% INPUTS:
% example: 1: 3 balls/spheres, 2: 100 balls/spheres.
% domain: 1. volume, 2. surface.
%---------------------------------------------------------------------------------
% OUTPUTS:
% centers,radii,xP,x0: parameters defining the domain
%---------------------------------------------------------------------------------

switch example

    case 1 % 3 spheres
        centers = [0 0 0;  0 1.3 -0.2;  2.5 0 1];
        radii = [1.4, 0.9, 2.6];
        xP = [-1.4,0,0];
        x0 = [0,0,0] + (domain==2)*xP;

    case 2  % 100 spheres
        rng(1000);
        N=100;
        centers=2*rand(N,3);
        radii=0.2+0.4*rand(1,N);
        xP = [centers(2,1)-radii(1),centers(2,2),centers(2,3)];
        x0 = [0,0,0] + (domain==2)*xP;

end

Nballs=length(radii);

switch domain
    case 1
        fprintf('\n \t The domain is a volume, defined by %4.0f balls', Nballs);
    case 2
        fprintf('\n \t The domain is a surface, defined by %4.0f spheres', Nballs);
end







function [f1,f2,f3,f4,TrueInt]=reference_values(domain,example,test_tunction)

f1=[]; f2=[]; f3=[]; f4=[]; TrueInt=[];

% Reference values - 10^8 pts in a box if domain=1, 10^6 pts in each sph if domain=2
switch domain
    case 1 % VOLUME TESTS
        switch example
            case 1 % 3 BALLS
                f1 = 4.627031205103873e+00;
                f2 = 4.507365722624769e+00;
                f3 = 3.171237898962495e+03;
                f4 = 5.165738959364841e+04;
                TrueInt = (test_tunction==0)*f1+(test_tunction==1)*f2+(test_tunction==2)*f3+...
                    (test_tunction==3)*f4;

            case 2 % 100 BALLS
                f1 = 1.237619835238622e+00;
                f2 = -5.255912711075771e+00;
                f3 = 1.575084016747666e+02;
                f4 = 1.133396458475565e+03;
                TrueInt = (test_tunction==0)*f1+(test_tunction==1)*f2+(test_tunction==2)*f3+...
                    (test_tunction==3)*f4;

        end

    case 2 % SURFACE TESTS
        switch example

            case 1 % 3 SPHERES
                f1 = 3.151451762951252e+00;
                f2 = 1.838458313530846e+01;
                f3 = 1.044688340952473e+04;
                f4 = 3.255449020972515e+05;
                TrueInt = (test_tunction==0)*f1+(test_tunction==1)*f2+(test_tunction==2)*f3+...
                    (test_tunction==3)*f4;

            case 2 % 100 SPHERES
                f1 = 4.216202315427962e+00;
                f2 = -8.937946455186765e+00;
                f3 = 4.691870151409881e+02;
                f4 = 3.157599278192318e+03;
                TrueInt = (test_tunction==0)*f1+(test_tunction==1)*f2+(test_tunction==2)*f3+...
                    (test_tunction==3)*f4;

        end
end





function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end