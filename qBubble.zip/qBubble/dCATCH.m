function [nodes,w,momerr,dbox] = dCATCH(deg,X,u,LHDM_options,verbose)

%--------------------------------------------------------------------------
% Object:
% This routine implements the Caratheodory-Tchakaloff d-variate discrete
% measure compression.
% Examples of its application are probability measures (designs) or
% quadrature formulas.
% Moments are invariant (close to machine precision) up to degree "deg"
% and adapts to the (numerical) dimension of the polynomial space on the
% point set X.
% It works satisfactorily for low/moderate degrees, depending on the
% dimension.
%--------------------------------------------------------------------------
% Input:
% deg: polynomial exactness degree;
% X: d-column array of point coordinates;
% * u: 1-column array of positive weights, or positive scalar in
%    case of equal weights;
% * LHDM_options: structure containing the values of optimization 
%       parameters (see "LHDM.m" for details); 
% * verbose: 0: no information from routine;
%            1: relevant information from routine;
%
% Note: the variables with an asterisk "*" are not mandatory and can be 
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output:
% nodes: d-column array of extracted mass points coordinates; the variable
%    "nodes" has rows that are also rows of "X", i.e. nodes represent a subset
%    of "X";
% w: 1-column array of corresponding new positive weights;
% momerr: moment reconstruction error;
% * dbox: variable that defines a hyperrectangle with 
%    sides parallel to the axis, containing the domain (or pointset X in 
%    the discrete case). 
%    It is a matrix with dimension "2 x d", where "d" is the dimension of
%    the space in which it is embedded the domain. 
%    For instance, for a 2-sphere, it is "d=3", for a 2 dimensional  
%    polygon it is "d=2".
%    As example, the set "[-1,1] x [0,1]" is described as 
%                          "dbox=[-1 0; 1 1]".
%--------------------------------------------------------------------------
% Dates:
% Written by M. Dessole, F. Marcuzzi, M. Vianello - July 2020
%
% Modified by M. Dessole, A. Sommariva, M. Vianello - November 2020
%--------------------------------------------------------------------------

% .........................  Function Body ................................

% ..... troubleshooting .....

if nargin < 5, verbose=[]; end
if nargin < 4, LHDM_options=[]; end
if nargin < 3, u=[]; end

if isempty(verbose), verbose=0; end
if isempty(LHDM_options)
    dim = size(X,2);
    LHDM_options = struct( 'k', ceil(nchoosek(deg+dim,dim)*2/(deg*dim)),...
        'init', false, 'thres', 0.2222, 'thres_w', 0.8);
end
if isempty(u), u=1; end

% ..... Main code below .....

% Vandermonde-like matrix of a u-orthogonal polynomial basis on X
[U,~,~,~,dbox]=dORTHVAND(deg,X,u,[],[],[]);

if verbose
    fprintf('Vandermonde matrix size = %d x %d \n', size(U,1), size(U,2));
end

if size(U,1)<=size(U,2)
    if verbose
        fprintf('Vandermonde matrix not underdetermined: no compression');
        fprintf('\n');
    end
    % no compression expected
    nodes=X;
    
    if isscalar(u), u=u*ones(size(Q,1),1); end % weights saved as scalar
    w=u;
    momerr = 0;
    
else
    
    % further orthogonalization to reduce the conditioning
    [Q,~]=qr(U,0);
    
    % new moments
    if isscalar(u), u=u*ones(size(Q,1),1); end % weights saved as scalar
    orthmom=Q'*u;
    [nodes, w, momerr, ~]= NNLS(X, u, U, Q, orthmom, LHDM_options, verbose);
    
end










function [nodes, w, momerr, e]= NNLS(X, u, U, Q, orthmom, options, verbose)
% Caratheodory-Tchakaloff points and weights via accelerated NNLS

tic;
if  isfield(options,'lsqnonneg')
    if options.lsqnonneg
        if verbose
            fprintf('Matlab lsqnonneg \n');
        end
        [weights,~,~,~,output] = lsqnonneg(Q',orthmom);
        iter = output.iterations;
        cardP = [];
    else
        if verbose
            fprintf('LHDM \n');
        end
        [weights,~,~,iter]=LHDM(Q',orthmom,options,verbose);
    end
else
     if verbose
            fprintf('LHDM \n');
        end
    [weights,~,~,iter]=LHDM(Q',orthmom,options,verbose);
end
e = toc;

% indexes of nonvanishing weights and compression
ind=find(abs(weights)>0);
nodes=X(ind,:);
w=weights(ind);

% moment reconstruction error
momerr=norm(U(ind,:)'*w-U'*u)/norm(U'*u);

% displaying results
if verbose
    fprintf('NNLS number of outer iterations = %d \n', iter);
    fprintf('NNLS elapsed time = %.6f s  \n', e);
    fprintf('initial design cardinality = %4.0f \n',size(X,1));
    fprintf('concentrated support cardinality = %4.0f \n',length(w));
    fprintf('compression ratio = %4.0f \n',size(X,1)/length(w));
    fprintf('moment reconstruction error = %4.2e \n \n',momerr);
end










function [U,jvec,Q,R,dbox] = dORTHVAND(deg,X,u,jvec,C,dbox)

%--------------------------------------------------------------------------
% Object:
% This routine computes a Vandermonde-like matrix for degree "deg" on a 
% d-dimensional point cloud "X" in an total-degree discrete orthogonal 
% polynomial basis w.r.t. the positive weight array "u". 
%--------------------------------------------------------------------------
% Input:
% deg: total degree of the algebraic polynomial basis; 
% X: d-column array of point coordinates;
% * u: 1-column array of positive weights, or positive scalar in
%    case of equal weights;
% * jvec: vector of column indexes, selects a polynomial basis;  
% * C : Chebyshev-Vandermonde matrix on "jvec" basis
% * dbox: variable that defines a hyperrectangle with sides parallel to the
%    axis, containing the domain (or "X" in the discrete case). 
%    If "dbox" is not provided, it is the smaller "hyperrectangle", with 
%    sides parallel to the cartesian axes, containing the pointset "X".
%    It is a matrix with dimension "2 x d", where "d" is the dimension of
%    the space in which it is embedded the domain. 
%    For instance, for a 2-sphere, it is "d=3", for a 2 dimensional polygon 
%    it is "d=2".
%    As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
%
% Note: the variables with an asterisk "*" are not mandatory and can be 
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output:
% U: Vandermonde-like matrix in a "u"-orthogonal polynomial basis on "X"; 
% jvec: vector of column indexes, selects a polynomial basis;
% Q: orthogonal factor in the QR decomposition
%                  diag(sqrt(u))*C(:,jvec)=Q*R 
%    where "C=dCHEBVAND(n,X,dbox)";
% R: triangular factor in the QR decomposition
% dbox: variable that defines a hyperrectangle with sides parallel to the 
%    axis, containing the domain (or the pointset if "dbox" was not 
%    assigned as input variable.
%--------------------------------------------------------------------------
% Dates:
% Written by M. Dessole, F. Marcuzzi, M. Vianello - July 2020
%
% Modified by M. Dessole, A. Sommariva, M. Vianello - November 2020
%--------------------------------------------------------------------------

% ........................... Function body ...............................



% ...... troubleshooting ......

if nargin < 6, dbox=[]; end
if nargin < 5, C=[]; end
if nargin < 4, jvec=[]; end
if nargin < 3, u=[]; end

if isempty(C), [C,dbox]=dCHEBVAND(deg,X,dbox); end
if isempty(jvec), N=rank(C); else, N=length(jvec); end
if isempty(u), u=1; end




% ..... main code below .....

% ...... computing Vandermonde matrix "U" ......

% scaling the matrix rows by the sqrt of the weights 
B = zeros(size(C));
for k=1:length(C(1,:))
    B(:,k)=C(:,k).*sqrt(u);
end

% polynomial basis orthogonalization
if N<length(C(1,:)) 
    if isempty(jvec)
        [Q0,R0,pm]=qr(B,0); 
        jvec=pm(1:N);
        R=R0(1:N,1:N);
        Q=Q0(:,1:N);
    else
        [Q,R]=qr(B(:,jvec),0);
    end
else 
    [Q,R]=qr(B,0);
    jvec=(1:N);
end

U=C(:,jvec)/R;





