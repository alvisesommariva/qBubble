function [T,w,res,p,LHDM_stats]=cqmc_v1(deg,X,tol,wX,dom)

% computes a Compressed Quasi-Monte Carlo formula from a large
% low-discrepancy sequence on a low-dimensional compact set or
% manifold, preserving the QMC polynomial moments up to a given
% degree, via Tchakaloff sets and NNLS moment-matching

% G. Elefante, A. Sommariva, M. Vianello, University of Padova
% version 0.1, May 2022

% warning: works satisfactorily in low-dimension with low degrees

% INPUT:
% deg: polynomial degree
% X: d-column array of a low-discrepancy sequence
% tol: moment-matching residual tolerance

% OUTPUT:
% T: compressed points (subset of X)
% w: corresponding positive weights
% res: moment-matching residual


% FUNCTION BODY

% cardinality of the low-discrepancy sequence
M=length(X(:,1));
% Chebyshev-Vandermonde matrix of degree deg at X
[V,N]=orthvand3D(deg,X,dom);

% QMC moments
p=V'*wX;

% computing the compressed QMC formula

% initializing the candidate Tchakaloff set cardinality
k=N;

% initializing the residual
res=2*tol;
% increase percentage of a candidate Tchakaloff set
theta=1;

LHDM_stats=[];

while res>tol && k<=N
    % d-variate full-rank Chebyshev-Vandermonde matrix at X(1:k,:);

    % basis orthogonalization
    [Q,~]=qr(V,0);
    % orthogonal moments
    orthmom=Q'*wX;
    % nonnegative weights by NNLS
    [w,resnorm,~,iter] = LHDM(Q',orthmom);
    % w=lsqnonneg(Q',orthmom);
    LHDM_stats=[LHDM_stats; k iter];
    % moment-matching residual
    res=norm(V'*w-p);
    % updating the candidate Tchakaloff set cardinality
    k=floor((1+theta)*k);
end

% compressed formula
% indexes of the positive weights
ind=find(w>0);
% compressed support points selection
T=X(ind,:);
% corresponding positive weights
w=w(ind);

end