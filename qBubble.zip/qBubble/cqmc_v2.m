function [T,w,res,p,LHDM_stats]=cqmc_v2(deg,X,tol,comp_type,e,dom)

%--------------------------------------------------------------------------
% Object
%--------------------------------------------------------------------------
% The routine computes a Compressed Quasi-Monte Carlo formula from a large
% low-discrepancy sequence on a low-dimensional compact set preserving the
% QMC polynomial moments up to a given degree, via Tchakaloff sets and NNLS
% moment-matching.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: polynomial degree
% X: d-column array of a low-discrepancy sequence
% tol: moment-matching relative residual tolerance
% comp_type: compression algorithm. 1: lsqnonneg 2: LHDM. 3: LHDMv4.
% e: weights corresponding to X
% dom: domain type
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% T: compressed points (subset of X).
% w: positive weights (corresponding to T).
% res: moment-matching relative residual
% p: moments of a certain shifted tensorial Chebyshev basis (total
%   degree equal to deg).
% LHDM_stats: vector of cardinality and iterations along the compression
%     stages.
%--------------------------------------------------------------------------
% Dates
%--------------------------------------------------------------------------
% First version: May 28, 2022;
% Last update:: February 15, 2024.
%--------------------------------------------------------------------------
% Authors
%--------------------------------------------------------------------------
% G. Elefante, A. Sommariva, M. Vianello
%--------------------------------------------------------------------------
% Paper
%--------------------------------------------------------------------------
% 1. "CQMC: an improved code for low-dimensional Compressed Quasi-MonteCarlo
% cubature"
% 2. " Qbubble: a numerical code for compressed QMC volume and surface integration on 
% union of balls"
% G. Elefante, A. Sommariva and M. Vianello
%--------------------------------------------------------------------------


M=length(X(:,1));

if M <= 0 
    fprintf(2,'\n \t No point in domain ');
    T=[]; w=[]; res=[]; q=[]; LHDM_stats=[]; return; 
end

% 1.2: Chebyshev-Vandermonde matrix of degree deg at X
[V,N] = orthvand3D(deg,X,dom);

% 1.3: QMC moments
p=V'*e;

% 2: computing the compressed QMC formula
% 2.1: initializing the candidate Tchakaloff set cardinality
m=8*N; 
% 2.2: initializing the residual
res=2*tol;
% 2.3: increase percentage of a candidate Tchakaloff set
theta=2;
% iterative search of a Tchakaloff set by NNLS moment-matching
s=1;

LHDM_stats=[];

while res(end)>tol && m<=M
    % 2.4: reduced Chebyshev-Vandermonde matrix;
    Vm=V(1:m,:);
    % 2.5: qr-decomposition
    [Qm,Rm]=qr(Vm,0);
    % 2.6: modified qmc moments
    qm=(p'/Rm)';

    % 2.7: nonnegative weights by NNLS
    switch comp_type
        case 1
            % fprintf('\n \t -> lsqnonneg');
            [u,resnorm] = lsqnonneg(Qm',qm);
            iter=NaN;
        case 2
            % fprintf('\n \t -> LHDM');
            [u,resnorm,~,iter] = LHDM(Qm',qm);
        case 3
            % fprintf('\n \t -> LHDM_v4');
            [u,resnorm,~,iter] = LHDM_v4(Qm',qm);
    end
    
    % 2.8: relative residual
    res(s)=norm(Vm'*u-p)/norm(p);
    
    LHDM_stats=[LHDM_stats; m iter];
    
    % 2.9: updating the candidate Tchakaloff set cardinality
    m=floor(theta*m);
    
    s=s+1;
end % while

% compressed formula
% 2.10: indexes of the positive weights
ind=find(u>0);
% 2.11: compressed support points selection
T=X(ind,:);
% 2.12: corresponding positive weights
w=u(ind);

