function [V,N] = orthvand3D(deg,X,dom,box)

% computes an orthogonal Vandermonde-like matrix on a 3D discrete set X


% INPUT:

% deg = polynomial degree

% X = 3-column array of point coordinates

% box = 6-component vector such that the box
% [box(1),box(2)] x [box,box(4)] x [box(5),box(6)] contains X
% if box=[] it will be determined by X

% OUTPUT:

% V = orthogonal Chebyshev-Vandermonde matrix


% FUNCTION BODY

if nargin < 4, box=[]; end
if isempty(box) 
    a=min(X); b=max(X); box=[a;b];
end

% 3D Chebyshev-Vandermonde matrix
[C,~]=dCHEBVAND(deg,X,box);

% dimension of the polynomial space on X
switch dom
    case 1
        N=length(C(1,:));
        V = C;
    case 2
        nu=length(C(1,:));
        N=rank(C(1:nu,1:nu));
        tic
        [~,~,p] = qr(C(1:nu,1:nu),0);
        cpu_tme = toc;
        fprintf('\n \t QR cpu time: %1.2e',cpu_tme);
        Cp = C(:,p);
        V = Cp(:,1:N);
end



end